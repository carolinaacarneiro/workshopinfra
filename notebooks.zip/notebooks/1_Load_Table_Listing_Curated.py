# Databricks notebook source
df = spark.sql("SELECT * FROM carol_carneiro.airbnbdemo.airbnb_rio_listing_detailed")
display(df)

# COMMAND ----------

df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC Fix ValueError: could not convert string to float: '$67.00'

# COMMAND ----------

from pyspark.sql.functions import regexp_replace, col

df = df.withColumn("price", regexp_replace(col("price"), "[^\d.]", "").cast("float"))

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df.display()

# COMMAND ----------

df.write.format("delta").mode("overwrite").saveAsTable("carol_carneiro.airbnbdemo.airbnb_rio_listing_detailed_curated")
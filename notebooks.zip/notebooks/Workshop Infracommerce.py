# Databricks notebook source
# MAGIC %md
# MAGIC # Workshop Infracommerce - Análise de Anúncios de Airbnb usando Databricks
# MAGIC
# MAGIC O objetivo é criar um modelo de Regressão linear para prever preço de Airbnb. 

# COMMAND ----------

# MAGIC %md
# MAGIC Este notebook irá:
# MAGIC
# MAGIC - Baixar o conjunto de dados da internet
# MAGIC - Carregar o conteúdo do arquivo CSV para um Spark Dataframe usando Spark
# MAGIC - Escrever o Spark Dataframe em uma Delta Table
# MAGIC - Consultar a nova Delta Table
# MAGIC
# MAGIC Notebook criado por Carolina Carneiro (carolina.carneiro@databricks.com) baseado no trabalho do Caio Moreno (caio.moreno@databricks.com)
# MAGIC
# MAGIC Original data from:https://insideairbnb.com/get-the-data/

# COMMAND ----------

# MAGIC %md
# MAGIC # Criação de um catálogo e de um schema:
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Primeiro vamos criar um catálogo.
# MAGIC
# MAGIC Se você preferir pode criar através da UI ou executar a seguinte célula. 

# COMMAND ----------

#substitua o demos_carol pelo nome de sua preferencia

spark.sql("CREATE CATALOG demos_carol")
spark.sql("USE CATALOG demos_carol")

# COMMAND ----------

# MAGIC %md
# MAGIC Agora vamos criar um schema.
# MAGIC
# MAGIC Se você preferir pode criar através da UI ou executar a seguinte célula. 

# COMMAND ----------

#substitua o workshopinfra pelo nome de sua preferencia

spark.sql("CREATE SCHEMA workshopinfra")
spark.sql("USE SCHEMA workshopinfra")

# COMMAND ----------

# MAGIC %md
# MAGIC Agora vamos criar um volume dentro do schema criado anteriormente. 
# MAGIC
# MAGIC Se você prefeir pode criar através da UI ou executar a seguinte célula.

# COMMAND ----------

#substitua o dadosairbnb pelo nome de sua preferencia

spark.sql("CREATE VOLUME dadosairbnb")

# COMMAND ----------

# MAGIC %md
# MAGIC Volume:<BR>
# MAGIC https://docs.databricks.com/en/connect/unity-catalog/volumes.html

# COMMAND ----------

# MAGIC %md
# MAGIC Obter o path do volume:
# MAGIC /Volumes/demos_carol/workshopinfra/dadosairbnb

# COMMAND ----------

# MAGIC %md
# MAGIC Copiar os dados do Airbnb para o volume

# COMMAND ----------

# MAGIC %sh
# MAGIC cd /Volumes/demos_carol/workshopinfra/dadosairbnb
# MAGIC wget https://data.insideairbnb.com/brazil/rj/rio-de-janeiro/2025-03-19/data/listings.csv.gz 

# COMMAND ----------

# MAGIC %sh
# MAGIC # Command to remove files 
# MAGIC #rm -rf /Volumes/cm_airbnb_mad_demo/airbnb_mad/airbnb_mad/listings.csv.gz
# MAGIC #rm -rf /Volumes/cm_airbnb_mad_demo/airbnb_mad/airbnb_mad/listings.csv.gz.1
# MAGIC #rm -rf /Volumes/cm_airbnb_mad_demo/airbnb_mad/airbnb_mad/listings.csv

# COMMAND ----------

# MAGIC %md
# MAGIC Listas os arquivos no volume

# COMMAND ----------

# MAGIC %sh
# MAGIC cd /Volumes/demos_carol/workshopinfra/dadosairbnb
# MAGIC ls -lh

# COMMAND ----------

# MAGIC %md
# MAGIC Descomprimir o arquivo

# COMMAND ----------

# MAGIC %sh
# MAGIC gzip -d /Volumes/demos_carol/workshopinfra/dadosairbnb/listings.csv.gz

# COMMAND ----------

# MAGIC %md
# MAGIC Listar os arquivos

# COMMAND ----------

# MAGIC %sh
# MAGIC cd /Volumes/demos_carol/workshopinfra/dadosairbnb
# MAGIC ls -lh

# COMMAND ----------

# MAGIC %md
# MAGIC Carregar Listing.csv do volume 

# COMMAND ----------

air_bnb_df = spark.read.csv("/Volumes/demos_carol/workshopinfra/dadosairbnb/listings.csv", header=True, inferSchema=True,multiLine="true", escape='"')
display(air_bnb_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Criar uma tabela a partir do csv do volume

# COMMAND ----------

air_bnb_df.write.format("delta").mode("overwrite").saveAsTable("airbnb_rio_listing_detailed")

# COMMAND ----------

# MAGIC %md
# MAGIC Visualizar a tabela

# COMMAND ----------

df = spark.sql("SELECT * FROM airbnb_rio_listing_detailed")
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC Vamos entender qual é o schema dessa tabela

# COMMAND ----------

df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC Limpar e converter uma coluna de preços em um DataFrame

# COMMAND ----------

from pyspark.sql.functions import regexp_replace, col

df = df.withColumn("price", regexp_replace(col("price"), "[^\d.]", "").cast("float"))

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC Criar uma nova tabela com o ajuste de Dataframe.

# COMMAND ----------

df.write.format("delta").mode("overwrite").saveAsTable("airbnb_rio_listing_detailed_curated")

# COMMAND ----------

# MAGIC %md
# MAGIC # Para tudo!!! Bora testar o Genie com os dados do Airbnb!

# COMMAND ----------

# MAGIC %md
# MAGIC # Vamos agora fazer seleção de Features para criação do primeiro modelo de Regressão
# MAGIC
# MAGIC Colunas para se manter: latitude, longitude, property_type, bathrooms, bedrooms, beds, amenities, price
# MAGIC
# MAGIC

# COMMAND ----------

df_curated_ml_model = spark.sql("SELECT id, latitude, longitude, bathrooms, bedrooms, beds, price FROM airbnb_rio_listing_detailed_curated")
display(df_curated_ml_model)

# COMMAND ----------

# MAGIC %md
# MAGIC Vamos remover as linhas onde o preço é nulo

# COMMAND ----------

df_curated_ml_model = df_curated_ml_model.dropna(subset=["price"])

# COMMAND ----------

# MAGIC %md
# MAGIC Vamos visualizar como ficou o df

# COMMAND ----------

display(df_curated_ml_model)

# COMMAND ----------

# MAGIC %md
# MAGIC Vamos salvar em uma nova tabela

# COMMAND ----------

df_curated_ml_model.write.format("delta").mode("overwrite").saveAsTable("airbnb_rio_listing_curated_ml_model")

# COMMAND ----------

df_curated_ml_model = spark.sql("SELECT id, latitude, longitude, bathrooms, bedrooms, beds, price FROM airbnb_rio_listing_curated_ml_model")
display(df_curated_ml_model)

# COMMAND ----------

# MAGIC %md
# MAGIC Adicionando restrições na tabela criada que o id não pode ser nulo e a coluna id é a primary key da tabela.

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE airbnb_rio_listing_curated_ml_model
# MAGIC ALTER COLUMN id SET NOT NULL;
# MAGIC
# MAGIC ALTER TABLE airbnb_rio_listing_curated_ml_model
# MAGIC ADD CONSTRAINT airbnb_rio_listing_curated_ml_model_pk PRIMARY KEY (id);

# COMMAND ----------

# MAGIC %md
# MAGIC ## Feature Engineering

# COMMAND ----------

# Install the databricks-feature-engineering package
%pip install databricks-feature-engineering
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC Agora vamos selecionar as features para o nosso modelo

# COMMAND ----------

from databricks.feature_engineering import FeatureEngineeringClient
fe = FeatureEngineeringClient()

# read data from the feature store
table_name = "airbnb_rio_listing_curated_ml_model"

#feature_data_pd_ml = fe.read_table(name=table_name)
feature_data_pd_ml = fe.read_table(name=table_name).toPandas()
feature_data_pd_ml = feature_data_pd_ml.drop(columns=['id'])


# Print the updated DataFrame
feature_data_pd_ml = feature_data_pd_ml.fillna(0)

# COMMAND ----------

# MAGIC %md
# MAGIC Podemos ver que não estamos mais usando a coluna id

# COMMAND ----------

display(feature_data_pd_ml)

# COMMAND ----------

# MAGIC %md
# MAGIC # Divisão do Dataset Treino / Teste
# MAGIC
# MAGIC Divisão do conjunto de dados em conjuntos de treinamento e teste. Isso é essencial para avaliar o desempenho de modelos de aprendizado de máquina.

# COMMAND ----------

from sklearn.model_selection import train_test_split

print(f"We have {feature_data_pd_ml.shape[0]} records in our source dataset")

# split target variable into it's own dataset
target_col = "price"
X_all = feature_data_pd_ml.drop(labels=target_col, axis=1)
y_all = feature_data_pd_ml[target_col]

# test / train split
X_train, X_test, y_train, y_test = train_test_split(X_all, y_all, train_size=0.7, random_state=42)
print(f"We have {X_train.shape[0]} records in our training dataset")
print(f"We have {X_test.shape[0]} records in our test dataset")

# COMMAND ----------

X_train.dtypes

# COMMAND ----------

display(X_train)

# COMMAND ----------

display(X_test)

# COMMAND ----------

display(y_train)

# COMMAND ----------

display(y_test)

# COMMAND ----------

# MAGIC %md
# MAGIC # Examinar para Potencial Colinearidade
# MAGIC # 
# MAGIC Agora, vamos examinar as correlações entre os preditores para identificar uma potencial colinearidade. Compreender as relações entre diferentes características pode fornecer insights sobre o conjunto de dados e nos ajudar a tomar decisões informadas durante o processo de modelagem.
# MAGIC
# MAGIC Vamos revisar a matriz de correlação em formato tabular. Além disso, podemos criar um gráfico baseado na matriz de correlação para inspecionar facilmente a matriz.

# COMMAND ----------

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
# Combine X and y into a single DataFrame for simplicity
data = pd.concat([X_train, y_train], axis=1)

# Calculate correlation matrix
corr = data.corr()

# display correlation matrix
pd.set_option('display.max_columns', 10)
print(corr)

# COMMAND ----------

# display correlation matrix visually

# Initialize figure
plt.figure(figsize=(8, 8))
for i in range(len(corr.columns)):
    for j in range(len(corr.columns)):
        # Determine the color based on positive or negative correlation
        color = 'blue' if corr.iloc[i, j] > 0 else 'red'

        # don't fill in circles on the diagonal
        fill = not( i == j )

        # Plot the circle with size corresponding to the absolute value of correlation
        plt.gca().add_patch(plt.Circle((j, i), 
                                       0.5 * np.abs(corr.iloc[i, j]), 
                                       color=color, 
                                       edgecolor=color,
                                       fill=fill,
                                       alpha=0.5))



plt.xlim(-0.5, len(corr.columns) - 0.5)
plt.ylim(-0.5, len(corr.columns) - 0.5)
plt.gca().set_aspect('equal', adjustable='box')
plt.xticks(np.arange(len(corr.columns)), corr.columns, rotation=90)
plt.yticks(np.arange(len(corr.columns)), corr.columns)
plt.title('Correlogram')
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC # Ajustar um Modelo de Regressão
# MAGIC
# MAGIC Para melhorar o desempenho do nosso modelo de regressão, vamos escalar nossas variáveis de entrada para que elas estejam em uma escala comum (padronizada). A padronização garante que cada feature (característica) tenha uma média de 0 e um desvio padrão de 1, o que pode ser benéfico para certos algoritmos, incluindo a regressão linear.

# COMMAND ----------

from math import sqrt

import mlflow.sklearn

from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_percentage_error

# turn on autologging
mlflow.sklearn.autolog(log_input_examples=True)

# apply the Standard Scaler to all our input columns
std_ct = ColumnTransformer(transformers=[("scaler", StandardScaler(), ["bathrooms", "bedrooms", "beds", "latitude", "longitude"])])

#"bathrooms", "bedrooms", "beds", "latitude", "longitude", "price"

# pipeline to transform inputs and then pass results to the linear regression model
lr_pl = Pipeline(steps=[
  ("tx_inputs", std_ct),
  ("lr", LinearRegression() )
])

# fit our model
lr_mdl = lr_pl.fit(X_train, y_train)

# evaluate the test set
predicted = lr_mdl.predict(X_test)
test_r2 = r2_score(y_test, predicted)
test_mse = mean_squared_error(y_test, predicted)
test_rmse = sqrt(test_mse)
test_mape = mean_absolute_percentage_error(y_test, predicted)
print("Test evaluation summary:")
print(f"R^2: {test_r2}")
print(f"MSE: {test_mse}")
print(f"RMSE: {test_rmse}")
print(f"MAPE: {test_mape}")

# COMMAND ----------

lr_mdl

# COMMAND ----------

import pandas as pd
import numpy as np
from scipy import stats

# Extracting coefficients and intercept
coefficients = np.append([lr_mdl.named_steps['lr'].intercept_], lr_mdl.named_steps['lr'].coef_)
coefficient_names = ['Intercept'] + X_train.columns.to_list()

# Calculating standard errors and other statistics (this is a simplified example)
# In a real scenario, you might need to calculate these values more rigorously
n_rows, n_cols = X_train.shape
X_with_intercept = np.append(np.ones((n_rows, 1)), X_train, axis=1)
var_b = test_mse * np.linalg.inv(np.dot(X_with_intercept.T, X_with_intercept)).diagonal()
standard_errors = np.sqrt(var_b)
t_values = coefficients / standard_errors
p_values = [2 * (1 - stats.t.cdf(np.abs(i), (len(X_with_intercept) - 1))) for i in t_values]

# Creating a DataFrame for display
summary_df = pd.DataFrame({'Coefficient': coefficients,
                           'Standard Error': standard_errors,
                           't-value': t_values,
                           'p-value': p_values},
                          index=coefficient_names)

# Print the DataFrame
print(summary_df)

# COMMAND ----------

import matplotlib.pyplot as plt

# Plotting the feature importances
plt.figure(figsize=(10, 6))
y_pos = np.arange(len(coefficient_names))
plt.bar(y_pos, coefficients, align='center', alpha=0.7)
plt.xticks(y_pos, coefficient_names, rotation=45)
plt.ylabel('Coefficient Size')
plt.title('Coefficients in Linear Regression')

plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC # Vamos agora Registrar o Modelo

# COMMAND ----------

# MAGIC %pip install "mlflow-skinny[databricks]>=2.4.1"
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

# MAGIC %md
# MAGIC Agora precisamos saber qual execução foi a melhor para registrar. No nosso caso só teremos 1. 
# MAGIC
# MAGIC Para saber o Run ID:
# MAGIC
# MAGIC 1. Acesse experiments
# MAGIC 2. Selecione o nome que tem o seu Notebook 
# MAGIC 3. Selecione a execução que aparece
# MAGIC 4. Copie o RunID
# MAGIC
# MAGIC Cole o run id no seguinte local:
# MAGIC
# MAGIC runs:RUNID/model
# MAGIC

# COMMAND ----------

import mlflow
catalog = "demos_carol"
schema = "workshopinfra"
model_name = "airbnb_rio_listing_curated_ml_model-best-model01"
mlflow.set_registry_uri("databricks-uc")
mlflow.register_model("runs:/cb25e1e6e0594e84b5940fcf72fabbdd/model", f"{catalog}.{schema}.{model_name}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Fazer Inferências com o Modelo

# COMMAND ----------

# MAGIC %pip install "mlflow-skinny[databricks]>=2.4.1"
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import mlflow
import pandas as pd

# Define the input data
data = {"columns": ["latitude", "longitude", "bathrooms", "bedrooms", "beds"], "data": [[-22.9224, -43.173416, 1.0, 3.0, 4.0], [-23.00589, -43.3466, 1.5, 1.0, 2.0], [-22.91683, -43.22247, 2.0, 4.0, 4.0], [-22.98418, -43.194543, 2.5, 2.0, 0.0], [-22.98291, -43.22652, 1.0, 1.0, 1.0]]}

# COMMAND ----------

# MAGIC %md
# MAGIC Predict on a Pandas DataFrame:

# COMMAND ----------

import mlflow
import pandas as pd

# Define the input data
data = {"columns": ["latitude", "longitude", "bathrooms", "bedrooms", "beds"], "data": [[-22.9224, -43.173416, 1.0, 3.0, 4.0], [-23.00589, -43.3466, 1.5, 1.0, 2.0], [-22.91683, -43.22247, 2.0, 4.0, 4.0], [-22.98418, -43.194543, 2.5, 2.0, 0.0], [-22.98291, -43.22652, 1.0, 1.0, 1.0]]}

# Load the model
logged_model = 'runs:/882dddd6315147d8b4741d1f21fe58df/model'
loaded_model = mlflow.pyfunc.load_model(logged_model)

# Create a DataFrame from the input data
input_df = pd.DataFrame(data["data"], columns=data["columns"])

# Predict using the loaded model
prediction = loaded_model.predict(input_df)

# Display the prediction
prediction

# COMMAND ----------

# MAGIC %md
# MAGIC Vamos testar valores diferentes:

# COMMAND ----------

import mlflow
import pandas as pd

# Define the input data
data = {"columns": ["latitude", "longitude", "bathrooms", "bedrooms", "beds"], "data": [[-22.95221, -43.32944, 5.0, 5.0, 10.0], [-22.98767, -43.18991, 1.0, 2.0, 3.0], [-22.97333, -43.18857, 2.0, 3.0, 6.0], [-22.96477, -43.17605, 1, 0, 2.0], [-22.9682, -43.18523, 1.0, 1.0, 2.0]]}

# Load the model
logged_model = 'runs:/882dddd6315147d8b4741d1f21fe58df/model'
loaded_model = mlflow.pyfunc.load_model(logged_model)

# Create a DataFrame from the input data
input_df = pd.DataFrame(data["data"], columns=data["columns"])

# Predict using the loaded model
prediction = loaded_model.predict(input_df)

# Display the prediction
prediction

# COMMAND ----------

# MAGIC %md
# MAGIC # Desafio!!!
# MAGIC
# MAGIC Criar um app com uma interface amigável para realizar inferências!
# Databricks notebook source
#carol_carneiro.airbnbdemo.airbnb_rio_listing_detailed_curated_ml_model-best-model01

# COMMAND ----------

# MAGIC %pip install "mlflow-skinny[databricks]>=2.4.1"
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import mlflow
import pandas as pd

# Define the input data
data = {"columns": ["latitude", "longitude", "bathrooms", "bedrooms", "beds"], "data": [[-22.9224, -43.173416, 1.0, 3.0, 4.0], [-23.00589, -43.3466, 1.5, 1.0, 2.0], [-22.91683, -43.22247, 2.0, 4.0, 4.0], [-22.98418, -43.194543, 2.5, 2.0, 0.0], [-22.98291, -43.22652, 1.0, 1.0, 1.0]]}

# COMMAND ----------

# MAGIC %md
# MAGIC Predict on a Pandas DataFrame:

# COMMAND ----------

import mlflow
import pandas as pd

# Define the input data
data = {"columns": ["latitude", "longitude", "bathrooms", "bedrooms", "beds"], "data": [[-22.9224, -43.173416, 1.0, 3.0, 4.0], [-23.00589, -43.3466, 1.5, 1.0, 2.0], [-22.91683, -43.22247, 2.0, 4.0, 4.0], [-22.98418, -43.194543, 2.5, 2.0, 0.0], [-22.98291, -43.22652, 1.0, 1.0, 1.0]]}

# Load the model
logged_model = 'runs:/882dddd6315147d8b4741d1f21fe58df/model'
loaded_model = mlflow.pyfunc.load_model(logged_model)

# Create a DataFrame from the input data
input_df = pd.DataFrame(data["data"], columns=data["columns"])

# Predict using the loaded model
prediction = loaded_model.predict(input_df)

# Display the prediction
prediction

# COMMAND ----------

# MAGIC %md
# MAGIC Try different values

# COMMAND ----------

import mlflow
import pandas as pd

# Define the input data
data = {"columns": ["latitude", "longitude", "bathrooms", "bedrooms", "beds"], "data": [[-22.95221, -43.32944, 5.0, 5.0, 10.0], [-22.98767, -43.18991, 1.0, 2.0, 3.0], [-22.97333, -43.18857, 2.0, 3.0, 6.0], [-22.96477, -43.17605, 1, 0, 2.0], [-22.9682, -43.18523, 1.0, 1.0, 2.0]]}

# Load the model
logged_model = 'runs:/882dddd6315147d8b4741d1f21fe58df/model'
loaded_model = mlflow.pyfunc.load_model(logged_model)

# Create a DataFrame from the input data
input_df = pd.DataFrame(data["data"], columns=data["columns"])

# Predict using the loaded model
prediction = loaded_model.predict(input_df)

# Display the prediction
prediction
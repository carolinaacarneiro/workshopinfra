# AI/BI Genie + Databricks SQL Serverless Workshop
The aims of this repo is to create a hands on AI/BI Genie + Databricks SQL Serverless Workshop .

# Products used
- Databricks SQL Serverless
- Databricks Serverless Workflows
- AI/BI Genie
- Notebooks
- Unity Catalog

### Labs
This short workshop has some labs.

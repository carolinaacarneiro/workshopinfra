# Databricks notebook source
# MAGIC %pip install "mlflow-skinny[databricks]>=2.4.1"
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

# carol_carneiro.airbnbdemo.airbnb_rio_listing_detailed_curated_ml_model
import mlflow
catalog = "carol_carneiro"
schema = "airbnbdemo"
model_name = "airbnb_rio_listing_detailed_curated_ml_model-best-model01"
mlflow.set_registry_uri("databricks-uc")
mlflow.register_model("runs:/882dddd6315147d8b4741d1f21fe58df/model", f"{catalog}.{schema}.{model_name}")